using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using Microsoft.Xna.Framework.Net;
using Microsoft.Xna.Framework.Storage;
using MathNet;

namespace LDA
{

    public class featureVector
    { 
        private int classis;
        private double[,] features;

        public featureVector(int features, int classis) {
            this.classis=classis;
            this.features = new double[1, features];
        }

        //Getter & setter
        public double this[int i, int j]
        {
            get
            {
                return features[i, j];
            }

            set
            {
                features[i, j] = value;
            }
        }

        public int getClass() {
            return this.classis;
        }

    }

    public class Classification
    {
        private int features;
        private List<featureVector> data;
        private MathNet.Numerics.LinearAlgebra.Matrix x_1;
        private MathNet.Numerics.LinearAlgebra.Matrix x_2;
        private MathNet.Numerics.LinearAlgebra.Matrix x;
        private MathNet.Numerics.LinearAlgebra.Matrix p;
        private MathNet.Numerics.LinearAlgebra.Matrix c;
        private MathNet.Numerics.LinearAlgebra.Matrix c_1;
        private MathNet.Numerics.LinearAlgebra.Matrix c_2;
        private MathNet.Numerics.LinearAlgebra.Matrix mean_u1;
        private MathNet.Numerics.LinearAlgebra.Matrix mean_u2;
        private MathNet.Numerics.LinearAlgebra.Matrix mean_u;
        

        public Classification(int features) {
            this.data = new List<featureVector>();
            this.features = features;            
        }



        public void addSample(featureVector s){
            data.Add(s);
        }

        

        public void train() {
            //Number of feature vectors each class
            int f1 = 0, f2 = 0;
            int j = 0, k = 0;
            //Initialize mean values arrays
            mean_u1 = new MathNet.Numerics.LinearAlgebra.Matrix(1, features);
            mean_u2 = new MathNet.Numerics.LinearAlgebra.Matrix(1, features);
            mean_u = new MathNet.Numerics.LinearAlgebra.Matrix(1, features);

            
            //Compute the mean values of train data
            foreach (featureVector item in data)
            {
                for (int i = 0; i < features; i++) {
                    if (item.getClass() == 1) { mean_u1[0, i] += item[0, i];}
                    if (item.getClass() == 2) { mean_u2[0, i] += item[0, i];}
                    mean_u[0, i] += item[0, i];
                }
                if (item.getClass() == 1) { f1++; }
                if (item.getClass() == 2) { f2++; }
            }

            for (int i = 0; i < features; i++) {
                mean_u[0, i] /= f1 + f2;
                mean_u1[0, i] /= f1;
                mean_u2[0, i] /= f2;
            }

            //Create classification matrices
            x_1 = new MathNet.Numerics.LinearAlgebra.Matrix(f1, features);
            x_2 = new MathNet.Numerics.LinearAlgebra.Matrix(f2, features);
            x   = new MathNet.Numerics.LinearAlgebra.Matrix(f1 + f2, features);
            foreach (featureVector item in data) {
                for (int i = 0; i < features; i++)
                {
                    if (item.getClass() == 1) { x_1[j, i] = item[0, i] - mean_u[0, i];}
                    if (item.getClass() == 2) { x_2[k, i] = item[0, i] - mean_u[0, i];}
                }
                if (item.getClass() == 1) { j++; }
                if (item.getClass() == 2) { k++; }
            }


            //Create covariance matrices
            c_1 = MathNet.Numerics.LinearAlgebra.Matrix.Transpose(x_1) * x_1;
            c_2 = MathNet.Numerics.LinearAlgebra.Matrix.Transpose(x_2) * x_2;

            for (int i = 0; i < features; i++) {
                for (j = 0; j < features; j++) {
                    c_1[i, j] /= f1;
                    c_2[i, j] /= f2;
                }
            }

            Console.Write(c_1.ToString());
            Console.Write(c_2.ToString());

            //Compute pooled covariance matrix
            c = new MathNet.Numerics.LinearAlgebra.Matrix(features, features);

            for (int i = 0; i < features; i++) {
                for (j = 0; j < features; j++) {
                    double d = ((double) f1 / ((double) f1 + (double) f2));
                    c[i, j] = ((double)f1 / ((double)f1 + (double)f2)) * c_1[i, j] + ((double)f1 / ((double)f1 + (double)f2)) * c_2[i, j]; 
                }
            }

            //Compute prior probability vector

            p = new MathNet.Numerics.LinearAlgebra.Matrix(1, 2);
            p[0, 0] = ((double)f1 / ((double)f1 + (double)f2));
            p[0, 1] = ((double)f2 / ((double)f1 + (double)f2));

            Console.Write(c.ToString());

        }

        public int classify(double[] vector)
        {
            //Compute the classification sums
            MathNet.Numerics.LinearAlgebra.Matrix v = new MathNet.Numerics.LinearAlgebra.Matrix(vector, 1);

            MathNet.Numerics.LinearAlgebra.Matrix sum_1 = this.mean_u1 * this.c.Inverse() * MathNet.Numerics.LinearAlgebra.Matrix.Transpose(v) - 0.5 * this.mean_u1 * this.c.Inverse() * MathNet.Numerics.LinearAlgebra.Matrix.Transpose(this.mean_u1);
            double su_1 = sum_1[0,0];
            double f_1 = su_1 + Math.Log(p[0, 0]);

            MathNet.Numerics.LinearAlgebra.Matrix sum_2 = this.mean_u2 * this.c.Inverse() * MathNet.Numerics.LinearAlgebra.Matrix.Transpose(v) - 0.5 * this.mean_u2 * this.c.Inverse() * MathNet.Numerics.LinearAlgebra.Matrix.Transpose(this.mean_u2);
            double su_2 = sum_2[0,0];
            double f_2 = su_2 + Math.Log(p[0, 1]);
            Console.WriteLine(f_1);
            Console.WriteLine(f_2);

            if (f_1 > f_2) { return 1; } else { return 2; }
        
        }
    }
}
